package jus.aor.mobilagent.classRMI;

import java.rmi.Remote;
import java.rmi.server.UnicastRemoteObject; 
import java.rmi.RemoteException; 

/**
 * @author morat 
 */
public interface ISupplier extends Remote {
	/**
	 * renvoie la reponse au service
	 * @return un T
	 * @throws RemoteException
	 */
	public Object service() throws RemoteException;
	/**
	 * renvoie l'annuaire
	 * @return un annuaire
	 * @throws RemoteException
	 */

	public String name() throws RemoteException;

}