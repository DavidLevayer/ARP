package jus.aor.mobilagent.classRMI;


import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

public class Customer extends Thread {
	private static String[] properties;
	private static int nbQuestion = 0;
	static{
		properties = System.getProperties().keySet().toArray(new String[] {});
		for(java.lang.reflect.Method m : ISupplier.class.getDeclaredMethods())
			if(m.getName().equals("question")) nbQuestion++;
	}
	
	String ou, qui, query; int num, client;
	private ISupplier obj;
	/**
	 * 
	 * @param ou designation de la machine distante
	 * @param qui nom generique du Provider
	 * @param num numemo specifique du Provider
	 * @param client numero du C
	 */
	public  Customer(String ou, String qui, int client,String query) {
		this.ou=ou; this.qui=qui;this.client=client; this.query=query;
	}
	public void run(){
		System.setProperty("java.rmi.server.hostname", "localhost");
		try{
			synchronized (Customer.class){
				System.out.println(this + "->" + "://" + ou + "/" + qui + num);
				try {
					obj = (ISupplier) LocateRegistry.getRegistry().lookup("rmi://"+ou+"/"+qui+query);
					} catch (Exception e) {
						System.out.println("Customer err: " + e);
					}
				System.out.println(" est lie a " + obj.name());
			}
			try{sleep((int) (Math.random() * 1000));}catch(Exception e){}
			synchronized (Customer.class){
					System.out.println(this + "->" + obj.name() + ".getHotels() = " + obj.service());

			}
		
		}catch(Throwable e){
			synchronized (Customer.class){
				System.out.println("Provider error: " + e);
			}
		}
	}
	public String toString()  {return "Customer"+client;}
	private String select() {return properties[(int)(Math.random()*properties.length)];}
}
