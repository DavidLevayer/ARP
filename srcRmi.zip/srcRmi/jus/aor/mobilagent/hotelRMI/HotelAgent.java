package jus.aor.mobilagent.hotelRMI;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jus.aor.mobilagent.kernel.Agent;
import jus.aor.mobilagent.kernel._Action;
import jus.aor.mobilagent.kernel._Service;

public class HotelAgent extends Agent {

	private static final long serialVersionUID = 1L;

	private Map<String,Hotel> hotelList;
	private String localisation;

	public HotelAgent(Object... args) throws URISyntaxException {
		super();
		this.className = this.getClass().getName();
		this.localisation = (String) args[0];
		this.hotelList = new HashMap<String,Hotel>();
	}

	protected _Action findHotel = new _Action(){

		private static final long serialVersionUID = 1L;

		public void execute() {
			//Getting access to the HotelService
			try {
				@SuppressWarnings("unchecked")
				_Service<Map<String,Hotel>> s = (_Service<Map<String,Hotel>>) agentServer.getService("Hotels");
				Map<String,Hotel> res = s.call(localisation);				
				hotelList.putAll(res);
			} catch (Exception e) {
				// Pas d'autre action... on passe au serveur suivant
				return;
			}
			//Adding hotels listed by the service to the agent personal hotel list
		}
	};

	protected _Action findTelephone = new _Action(){

		private static final long serialVersionUID = 1L;

		public void execute() {
			//Getting access to the HotelService
			try {
				@SuppressWarnings("unchecked")
				_Service<Map<String,Hotel>> s = (_Service<Map<String,Hotel>>) agentServer.getService("Telephones");
				hotelList = s.call(hotelList);
			} catch (Exception e) {
				// Pas d'autre action... on passe au serveur suivant
			}
		}
	};

	protected _Action retour = new _Action() {

		private static final long serialVersionUID = 1L;

		public void execute() {
			//Print the hotel list with associated phone numbers
			System.out.println("Hotels available at "+localisation+" ("+hotelList.size()+"):");
	
			Iterator<Hotel> i = hotelList.values().iterator();
			Hotel h;
			while(i.hasNext()) {
				h = i.next(); 
				System.out.println("Hotel "+h.getName()+ "tel: "+h.getPhoneNumber());
			}				
			System.out.println("End-----------------");
		}
	};
}
